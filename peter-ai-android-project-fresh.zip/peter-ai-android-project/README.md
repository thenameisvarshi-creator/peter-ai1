# Peter AI Android starter

This is an early starter project, not a complete Siri replacement.

## Current starter features
- Tap-to-talk speech recognition using Android's installed speech service.
- Spoken responses using Android Text-to-Speech.
- Basic commands to open YouTube, Chrome, and Android Settings.
- A call command opens the dialer for review; it does not place calls automatically.

Telugu and English availability depends on the speech recognition and text-to-speech languages installed on the phone.

## Build
Open this project in Android Studio, or use the included GitHub Actions workflow to build a debug APK.

The project has not been verified by a successful build in this package. The GitHub build may expose issues that need fixing.

## Planned, not yet implemented
AI backend, wake phrase, broad app automation, notification access, messaging, reminders, and sensitive-action confirmation flow.
